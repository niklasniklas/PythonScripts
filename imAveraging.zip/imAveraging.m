%%
% Calcualte difference from 2 images

clear all;
close all;
clc;


%A = imread('C:/Temp/xx/0001.bmp');
%B = imread('C:/Temp/rr.bmp');
A = imread('C:/Temp/Script (MatLab o Python)/Matlab/0008.bmp');
B = imread('C:/Temp/Script (MatLab o Python)/Matlab/0009.bmp');
C = imread('C:/Temp/Script (MatLab o Python)/Matlab/0010.bmp');
D = imread('C:/Temp/Script (MatLab o Python)/Matlab/0011.bmp');

E=(A/4)+(B/4)+(C/4)+(D/4);

fig = figure();
imshow(E);
imwrite(E,'aaa.tif');

%sum(sum(sum(C))) % ans=0 for identical images