%%
% Calcualte difference from 2 images

clear all;
close all;
clc;


%A = imread('C:/Temp/xx/0001.bmp');
%B = imread('C:/Temp/rr.bmp');
A = imread('C:/Temp/Script (MatLab o Python)/Matlab/0001.bmp');
B = imread('C:/Temp/Script (MatLab o Python)/Matlab/0005.bmp');

C= A-B;

imshow(C);
sum(sum(sum(C))) % ans=0 for identical images
%%
